export { cards } from "../index.js";
export const cardId = "birthday";
export function getCardConfig() { return cards.find(card => card.id === cardId); }
