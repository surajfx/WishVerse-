export { cards } from "../index.js";
export const cardId = "miss";
export function getCardConfig() { return cards.find(card => card.id === cardId); }
